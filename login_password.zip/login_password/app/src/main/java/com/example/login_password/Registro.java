package com.example.login_password;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registro extends AppCompatActivity {

    EditText ed1,ed2,ed3,ed4,ed5,ed6;
    Button v;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        v=(Button) findViewById(R.id.button7);

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Registro.this, MainActivity.class));
            }
        });


        //---------------------------------------------------------------------------------------------------------

        ed1=findViewById(R.id.ed1);
        ed2=findViewById(R.id.ed2);
        ed3=findViewById(R.id.ed3);
        ed4=findViewById(R.id.ed4);
        ed5=findViewById(R.id.ed5);
        ed6=findViewById(R.id.ed6);
    }

    public void altas(View view) {
        String dni= ed1.getText().toString();//nControl
        String nombre=ed2.getText().toString();
        String semestre=ed3.getText().toString();
        String carrera=ed4.getText().toString();
        String edad=ed5.getText().toString();
        String correo=ed6.getText().toString();
        ContentValues registro = new ContentValues();
        registro.put("nControl",dni);
        registro.put("nombre",nombre);
        registro.put("Semestre",semestre);
        registro.put("carrera",carrera);
        registro.put("edad",edad);
        registro.put("correo",correo);

        Toast.makeText(this," Los datos del usuario estan cargados",Toast.LENGTH_SHORT).show();
        startActivity(new Intent(Registro.this, Entrar.class));
        Toast.makeText(Registro.this, "SALUDOS NUEVO USUARIO", Toast.LENGTH_SHORT).show();
    }
}
