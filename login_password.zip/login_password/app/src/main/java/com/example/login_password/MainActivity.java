package com.example.login_password;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    Button r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //////////////////////////////////////////////////////////////////////////////////////

        r=(Button) findViewById(R.id.btnRG);

        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Registro.class));
            }
        });


        //---------------------------------------------------------------------------------------------------------

        TextView username =(TextView) findViewById(R.id.username);
        TextView password =(TextView) findViewById(R.id.password);

        MaterialButton loginbtn = (MaterialButton) findViewById(R.id.loginbtn);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().equals("usuario") && password.getText().toString().equals("123")) {
                    //correcto
                    Toast.makeText(MainActivity.this, "SESION INICIADA", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this, Entrar.class));
                    Toast.makeText(MainActivity.this, "SALUDOS USUARIO", Toast.LENGTH_SHORT).show();
                } else
                    //incorrecto
                    Toast.makeText(MainActivity.this, "ERROR SESION NO INICIADA", Toast.LENGTH_SHORT).show();

            }

        });
    }
}